﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMC
{
    public partial class Form1 : Form
    {
        double Peso, Altura, IMC;
        public Form1()

        {
            InitializeComponent();
        }

        private void mskbxPeso_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
           if (!double.TryParse(mskbxPeso.Text, out Peso))
            {
                MessageBox.Show("Valor Inválido");
            }
           else
            {
                if (Peso<=0 )
                {
                    MessageBox.Show("Não pode ser <=0");
                }
            }
        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbAltura.Text, out Altura))
            {
                MessageBox.Show("Valor Inválido");
            }
            else
            {
                if (Altura <= 0)
                {
                    MessageBox.Show("Não pode ser <=0");
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtClass_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double.TryParse(mskbAltura.Text, out Altura);
            double.TryParse(mskbxPeso.Text, out Peso);
             IMC= Peso / Math.Pow(Altura, 2);
             IMC = Math.Round(IMC, 1);
            txtIMC.Text = IMC.ToString();

            if (IMC<18.5)
            {
                txtClass.Text ="Magreza";
            }
            else
            {
                if (IMC<=24.9)
                {
                    txtClass.Text = "Normal";
                }
                else
                {
                    if (IMC <= 29.9)
                    {
                        txtClass.Text = "Sobre Peso";
                    }
                    else
                    {
                        if (IMC <= 39.9)
                        {
                            txtClass.Text = "Obesidade";
                        }
                        else
                        {
                        
                          txtClass.Text = "Obesidade Grave";
                        }
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            mskbxPeso.Clear();
            mskbAltura.Clear();
            txtIMC.Clear();
        }
    }
}
