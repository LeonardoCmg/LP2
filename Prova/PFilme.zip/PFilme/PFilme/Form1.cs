﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Microsoft.VisualBasic;

namespace PFilme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Executar_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[40, 2];
            string auxiliar;
            double media1 = 0, media2 = 0;

            lbxFilme.Items.Clear();

            for (var i = 0; i <40; i++)
            {
                for (var k = 0; k < 2; k++)
                {
                    auxiliar = Microsoft.VisualBasic.Interaction.InputBox("Pessoa:  " + (i + 1) + "  Digite a Nota do Filme " + (k + 1), "Entrada de Dados");

                    if (!double.TryParse(auxiliar, out notas[i, k]))
                    {
                        MessageBox.Show("Tipo de Nota Inválida!");
                        k--;
                    }

                    else

                    if (notas[i, k] < 0 || notas[i, k] > 10)
                    {
                        MessageBox.Show("Nota Inválida!");
                        k--;
                    }

                    else
                    {
                        if (k == 0)
                        {
                            media1 += notas[i, k];
                        }

                        else
                        {
                            media2 += notas[i, k];
                        }

                    }

                }
            }

            for (var g = 0; g < 40; g++)
            {
                lbxFilme.Items.Add("Pessoa " + (g + 1) + ": Nota do Filme 1: " + notas[g, 0].ToString("N2") + "  Nota do Filme 2: " + notas[g, 1].ToString("N2"));
            }
            lbxFilme.Items.Add("Média do Filme 1 : " + (media1 /= 40).ToString("N2"));
            lbxFilme.Items.Add("Média do Filme 2 : " + (media2 /= 40).ToString("N2"));
        }
    

    }
    

    
   
}

